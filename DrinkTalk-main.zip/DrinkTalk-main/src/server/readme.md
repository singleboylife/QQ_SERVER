服务端整体框架代码

可直接在当前目录下运行

```shell
#构建
[root@centos server]$ make 
#清除
[root@centos server]$ make clena
```

由ls老哥实现

